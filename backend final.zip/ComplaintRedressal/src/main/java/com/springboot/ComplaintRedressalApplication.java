package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComplaintRedressalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComplaintRedressalApplication.class, args);
	}

}
