export class AuthenticationStatus {
    username!: string;
    password!: string;
    authenticated!: boolean
    constructor() {}

}