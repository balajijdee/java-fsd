import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctordetails',
  templateUrl: './doctordetails.component.html',
  styleUrls: ['./doctordetails.component.css']
})
export class DoctordetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
