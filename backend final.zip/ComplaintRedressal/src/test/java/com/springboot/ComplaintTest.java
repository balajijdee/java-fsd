package com.springboot;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ComplaintTest {

    WebDriver driver;

@Test (priority=0)  
  public void testing() throws InterruptedException {
      

        long start = System.currentTimeMillis();
        driver.manage().window().maximize();
        driver.get("http://localhost:4200/home");
        long finish = System.currentTimeMillis();
        long totalTime = finish - start; 
        Thread.sleep(1000);
        //Testing Admin COmponents
        driver.navigate().to("http://localhost:4200/adminlogin");
       
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin-login/div/form/div[1]/input")).sendKeys("Admin");
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin-login/div/form/div[2]/input")).sendKeys("Admin");
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin-login/div/form/button")).click();
        System.out.println("sucessfully signUp ");
        Thread.sleep(1000);
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin/div[2]/div[1]/button")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin/div[2]/div[2]/button")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin/div[2]/div[3]/button")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin/div[2]/div[4]/button")).click();
        Thread.sleep(2000);
           driver.findElement(By.xpath("/html/body/app-root/div[2]/app-admin/div[2]/div[5]/button")).click();
        Thread.sleep(2000);
        System.out.println("sucessfully viewed Admin page components");
        
        
        System.out.println("Total Time for main page load = "+(totalTime*0.001)+" Seconds"); 
}
       

  
@Test (priority=1)  
  public void customersignin() throws InterruptedException  {
      //Customer Login And Raising Complaints
         driver.get("http://localhost:4200/customers");
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[2]/form/div[1]/input")).sendKeys("Manoj@gmai.com");
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[2]/form/div[2]/input")).sendKeys("1234567");
        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[2]/form/button")).click();
       
			Thread.sleep(3000);

			driver.findElement(By.xpath("/html/body/app-root/div[2]/app-complaints/div[2]/form/div[2]/input")).sendKeys("244567");
	        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-complaints/div[2]/form/div[3]/input")).sendKeys("Network Down");
	        
	        driver.findElement(By.xpath("/html/body/app-root/div[2]/app-complaints/div[2]/form/button")).click();
	        
	        System.out.println("sucessfully raised a complaint");	
      
      
		}
    
@Test (priority=2)  
public void customerregister() throws InterruptedException {

    driver.get("http://localhost:4200/customers");
    Thread.sleep(1000);
    driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[1]/input")).sendKeys("customer091@gmail.com");
    driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[2]/input")).sendKeys("12345");
    driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[3]/input")).sendKeys("customer091");
    driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[4]/input")).sendKeys("1232360391");
    driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[5]/input")).sendKeys("AK , street,chennai");
    driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/div[6]/input")).sendKeys("123456");
    driver.findElement(By.xpath("/html/body/app-root/div[2]/app-customers/div/div[1]/form/button[1]")).click();
    System.out.println("sucessfully Registerd as Customer");
   }

      
@Test (priority=4)  
public void managerregister() throws InterruptedException {
    //Register AS Manager
       driver.get("http://localhost:4200/managers");
      driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[1]/form/div[1]/input")).sendKeys("manager91gmail.com");
      driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[1]/form/div[2]/input")).sendKeys("12345");
      driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[1]/form/div[3]/input")).sendKeys("manager091");
      driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[1]/form/div[4]/input")).sendKeys("123456");
      driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[1]/form/button[1]")).click();
      System.out.println("sucessfully Registerd as Manager");
      try {
    	  driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +  "t");
    	  //Login And Assign Task TO Engineer

          driver.get("http://localhost:4200/managers");
         driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[2]/form/div[1]/input")).sendKeys("man@mail.com");
         driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[2]/form/div[2]/input")).sendKeys("12345");
         driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/div[2]/form/button")).click();
         Thread.sleep(1000);
         driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/table/tbody/tr[7]/div/form/td[6]/button")).click();
         driver.findElement(By.xpath("/html/body/app-root/div[2]/app-managers/div[2]/table/tbody/tr[1]/div/form/td[6]")).click();
         driver.findElement(By.xpath(" /html/body/app-root/div[2]/app-managers/div[2]/table/tbody/tr[1]/div/form/td[7]/button")).click();
         System.out.println("sucessfully logged in as manager and assigned complaint to engineer");
      }
      catch (UnhandledAlertException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     
   }


    @Test (priority=5)  
    public void engineerregisterLogin() throws InterruptedException {
    	//Login As Engineer
            driver.get("http://localhost:4200/engineers");
       driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[2]/form/div[1]/input")).sendKeys("Engineer2@gmail.com");
       driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[2]/form/div[2]/input")).sendKeys("12345");
       driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[2]/form/button")).click();
       Thread.sleep(1000);
       //Update Status of complaint
       driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/table/tbody/tr[1]/div/form/td[5]/input")).clear();
       Thread.sleep(1000);
       driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/table/tbody/tr[1]/div/form/td[5]/input")).sendKeys("Issue solved");
       driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/table/tbody/tr[1]/div/form/td[6]/button")).click();
       
       System.out.println("sucessfully loged in as engineer and updated complaint status");
       System.out.println("sucessfully logged in as Engineer");

    try {
    	//Register As A Engineer
        driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +  "t");
     	  
        driver.get("http://localhost:4200/engineers");
          Thread.sleep(1000);
           
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[1]/form/div[1]/input")).sendKeys("Engineer01@gmail.com");
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[1]/form/div[2]/input")).sendKeys("12345");
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[1]/form/div[3]/input")).sendKeys("Engineer01");
          driver.findElement(By.xpath("/html/body/app-root/div[2]/app-engineers/div[2]/div[1]/form/button[1]")).click();
          System.out.println("sucessfully Registerd as Engineer");
    }
          catch (UnhandledAlertException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
       }


  @BeforeMethod
    public void beforeMethod() {
        
      System.setProperty("webdriver.chrome.driver", "D:\\\\Java Training\\\\chromedriver_win32\\chromedriver.exe");
      driver=new ChromeDriver();
      driver.manage().window().maximize();
    }
  

    @AfterMethod
    public void afterMethod() {
        //driver.close();
         driver = null;
    }
}